# Fix File Path ucfirst Logic Spec

## Why
O log de debug revelou exatamente os caminhos testados:
1) `/home2/coninfom/public_html/patrimonio/app/Controllers/Superadmin/TenantController.php`
2) `/home2/coninfom/public_html/patrimonio/app/Controllers/superadmin/tenantcontroller.php`
3) `/home2/coninfom/public_html/patrimonio/app/Controllers/Superadmin/TenantController.php` (Idêntico ao 1)

O erro está na lógica de construção dos caminhos fallback. O caminho 1 e 3 ficaram idênticos porque a lógica de capitalização preservou o case original. Mais importante, o caminho 2 (`tenantcontroller.php`) colocou o nome do arquivo TODO em minúsculo, o que é fatal no Linux se o arquivo se chamar `TenantController.php`.

Se a pasta `Controllers` (com C maiúsculo) existe, e a pasta `superadmin` estiver em minúsculo no servidor FTP (o erro mais comum), o PHP deveria testar:
`/home2/coninfom/public_html/patrimonio/app/Controllers/superadmin/TenantController.php` (Note que o nome do arquivo é mantido original).

## What Changes
- Refatorar as linhas que geram `$fileLower` e `$fileUcfirst` no `Core/Router.php` para garantir que o **nome do arquivo (`TenantController.php`) nunca sofra alteração de case (nunca fique minúsculo)**, alterando o case *apenas* das subpastas (ex: `Superadmin` -> `superadmin`).

## Impact
- Affected specs: Resolução de caminhos fallback no Router.
- Affected code: `Core/Router.php`.

## ADDED Requirements
### Requirement: Preservação de Case no Nome do Arquivo
A rotina de fallback DEVE alterar apenas as subpastas para minúsculo/ucfirst, preservando estritamente o *CamelCase* original do nome do arquivo da classe.

#### Scenario: Success case
- **WHEN** a classe é `Superadmin/TenantController`
- **THEN** o fallback de minúsculas testa `superadmin/TenantController.php` em vez de `superadmin/tenantcontroller.php`.