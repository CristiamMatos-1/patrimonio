# Fix Routing and Case Sensitivity on cPanel Spec

## Why
O log de debug confirmou que a URL está sendo extraída e limpa perfeitamente (`URL tratada: /`). No entanto, o sistema continua retornando o erro 404 (Página não encontrada) ou parando a execução. Isso geralmente ocorre por dois motivos em hospedagens cPanel/Linux:
1. A linha de `die()` de debug está ativa, interrompendo a execução.
2. O sistema de arquivos do Linux é *Case-Sensitive* (diferencia maiúsculas de minúsculas). Se o cliente FTP enviou a pasta `app/Controllers` como `app/controllers`, o Autoloader PSR-4 nativo não consegue encontrar a classe `HomeController` e o Roteador acaba caindo na rota 404 final.

## What Changes
- Remover o código temporário de debug do arquivo `Core/Router.php`.
- Aprimorar o `Core/Autoloader.php` para ter um *fallback* inteligente: caso ele não encontre o arquivo no caminho exato com letras maiúsculas (ex: `app/Controllers/HomeController.php`), ele tentará buscar na versão com diretórios em minúsculo (ex: `app/controllers/HomeController.php`), mantendo a compatibilidade com uploads FTP de hospedagens compartilhadas.

## Impact
- Affected specs: Roteamento e Autoloading de classes.
- Affected code: `Core/Router.php`, `Core/Autoloader.php`.

## ADDED Requirements
### Requirement: Resiliência de Autoloading em Linux
O sistema DEVE ser capaz de carregar classes mesmo que os diretórios pai tenham sofrido alteração de *case* (maiúscula para minúscula) durante o upload via FTP.

#### Scenario: Success case
- **WHEN** o roteador solicita `App\Controllers\HomeController`
- **THEN** o Autoloader procura por `app/Controllers/HomeController.php` e, se falhar, tenta `app/controllers/HomeController.php`, instanciando a classe corretamente e evitando o erro 404.

## MODIFIED Requirements
### Requirement: Limpeza de Roteador
O roteador não deve mais imprimir mensagens de debug na tela, permitindo que o fluxo siga para o Controller.