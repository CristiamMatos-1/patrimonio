# Tasks
- [x] Task 1: Inserir as diretivas `ini_set('display_errors', 1);` e `error_reporting(E_ALL);` no topo do `index.php`.
- [x] Task 2: Modificar as Views (ex: `app/Views/home/index.php`) para usar uma constante ou função que já resolva o problema de maiúsculas/minúsculas da pasta `layouts` ou ajustar o código do `require` para ser flexível.