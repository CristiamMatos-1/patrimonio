# Fix White Screen (Fatal Error) on cPanel Spec

## Why
A aplicação ultrapassou o roteamento e encontrou as Views, mas a página ficou totalmente em branco. No PHP, uma "Tela Branca da Morte" (White Screen of Death - WSOD) significa que ocorreu um **Fatal Error** na sintaxe ou no carregamento e a exibição de erros (`display_errors`) está desativada no servidor de hospedagem por motivos de segurança.
Considerando as adaptações de *Case-Sensitivity* que fizemos recentemente (para o Autoloader e para o Controller), é quase certo que o arquivo base do layout HTML (`layouts/main.php`) não foi encontrado pelo mesmo motivo quando tentou ser incluído pela view `home/index.php`.

## What Changes
- Habilitar temporariamente a exibição de erros no arquivo principal `index.php` para que possamos ler o erro real na tela em vez de uma tela em branco.
- Ajustar os caminhos das views filhas (ex: `home/index.php` que chama `layouts/main.php`) para também usarem um mecanismo resiliente de *Case-Sensitivity*, ou garantir que os includes usem caminhos flexíveis.

## Impact
- Affected specs: Exibição de erros de debug.
- Affected code: `index.php`, `app/Views/home/index.php` e todas as views que fazem include manual do layout.

## ADDED Requirements
### Requirement: Exibição de Erros para Debug
O sistema DEVE exibir os erros fatais do PHP diretamente no navegador temporariamente para facilitar a identificação da causa da tela branca.

#### Scenario: Success case
- **WHEN** ocorre um erro fatal (ex: arquivo não encontrado no `require`)
- **THEN** o PHP imprime a mensagem de erro exata e a linha onde ocorreu, permitindo a correção imediata.