# Fix Autoloader Ultimate Bypass Spec

## Why
Se o log de erro continuou INTACTO (`ERRO: Classe App\Controllers\Superadmin\TenantController NÃO FOI ENCONTRADA pelo Autoloader`), e sabemos que adicionamos *logs e retornos diretos na força bruta*, a única explicação racional no PHP é que **a classe `Core\Autoloader` sequer está sendo invocada para essa classe, ou a string passada não está batendo em nenhum `if` por causa de caracteres invisíveis (como barras invertidas duplas).**

Vamos resolver isso com uma solução **CLARA E PERFEITA**: Abandonaremos a complexidade do Autoloader PSR-4 para hospedagens restritas. O Roteador vai simplesmente montar o caminho do arquivo e dar um `require_once` **diretamente no Router**, ignorando o Autoloader. Isso é uma técnica "Bulletproof" (à prova de balas) porque não depende da engine interna do PHP (`spl_autoload_register`) que claramente está falhando nesse cPanel específico.

## What Changes
- Modificar `Core/Router.php`. Quando houver um Match na rota, em vez de depender apenas do `class_exists()` e do Autoloader mágico, o Roteador vai traduzir fisicamente a string da classe em um caminho de arquivo, verificar se o arquivo existe (usando nossa função `bruteForceSearch` diretamente ali) e fazer um `require_once` forçado.

## Impact
- Affected specs: Roteamento e Carregamento de Classes.
- Affected code: `Core/Router.php`.

## ADDED Requirements
### Requirement: Require Direto pelo Router
O Router DEVE carregar o arquivo do Controller diretamente do disco rígido usando `require_once` antes de tentar instanciar a classe.

#### Scenario: Success case
- **WHEN** a rota é `/superadmin/tenant/create`
- **THEN** o Router traduz `App\Controllers\Superadmin\TenantController` para `BASE_PATH . '/app/Controllers/Superadmin/TenantController.php'`, faz o `require_once`, verifica o `class_exists` (que agora será true pois o arquivo já foi carregado) e executa o método.