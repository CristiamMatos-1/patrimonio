# Fix Superadmin Routing and Case Sensitivity Spec

## Why
O acesso à rota `/superadmin/tenant/create` está retornando 404. Sabemos que a rota raiz (`/`) e a rota de login (`/login`) funcionaram, então o roteador base está operacional. O problema do 404 em sub-rotas ocorre porque o nome da classe do Controller ou o seu Namespace não está casando com as regras *Case-Sensitive* do Autoloader no cPanel (ex: a rota aponta para `Superadmin\TenantController`, mas o FTP subiu a pasta como `superadmin`).

## What Changes
- Verificar e corrigir o *case* (letras maiúsculas/minúsculas) da definição de rota no `index.php`.
- Assegurar que a string de namespace passada para o roteador em `index.php` seja interpretada corretamente pelo nosso mecanismo de Autoloading, adicionando resiliência também para os namespaces que usam subpastas (`App\Controllers\Superadmin\...`).

## Impact
- Affected specs: Roteamento de subpastas (Superadmin e Tenant).
- Affected code: `index.php`, `Core/Router.php`, `Core/Autoloader.php`.

## ADDED Requirements
### Requirement: Resiliência em Sub-Namespaces no Roteador
O roteador e o autoloader DEVEM conseguir instanciar Controllers que estão dentro de subpastas (`Superadmin` ou `Tenant`), mesmo que as pastas físicas no servidor estejam em letras minúsculas devido ao FTP.

#### Scenario: Success case
- **WHEN** o usuário acessa `/superadmin/tenant/create`
- **THEN** o Roteador solicita a classe `App\Controllers\Superadmin\TenantController`. O Autoloader converte os segmentos adequadamente e encontra o arquivo, seja em `app/Controllers/Superadmin/` ou `app/controllers/superadmin/`.