# Fix Autoloader Namespace Case on cPanel Spec

## Why
O log de debug revelou o problema exato:
`ERRO: Classe App\Controllers\Superadmin\TenantController NÃO FOI ENCONTRADA pelo Autoloader.`

O Autoloader está recebendo a string da classe e falhando em localizá-la no servidor cPanel. Como a pasta raiz do namespace `App` é mapeada fisicamente para a pasta `app` (em minúsculo), e o Autoloader anterior tentou forçar tudo para minúsculo no *fallback*, ele acabou procurando `app/controllers/superadmin/TenantController.php`. Se a pasta real no servidor for `app/Controllers/Superadmin/` (tudo maiúsculo como no projeto local) ou qualquer outra variação mista de case, o `file_exists` do PHP no Linux retornará falso.

A abordagem mais resiliente para sistemas de hospedagem compartilhada (onde clientes FTP alteram o *case* aleatoriamente) não é adivinhar se é maiúsculo ou minúsculo, mas sim criar um Autoloader que mapeie a pasta dinamicamente ou tente combinações precisas baseadas na estrutura padrão do projeto.

## What Changes
- Refatorar o método `loadMappedFile` no `Core/Autoloader.php`.
- O fallback tentará as três combinações mais comuns de FTP:
  1. Caminho Original Exato (ex: `Controllers/Superadmin/TenantController.php`)
  2. Tudo em minúsculo (ex: `controllers/superadmin/TenantController.php`)
  3. Apenas a primeira letra maiúscula para pastas (padrão PSR-4), caso o FTP tenha alterado apenas a raiz.

## Impact
- Affected specs: Carregamento de Classes (Autoloading).
- Affected code: `Core/Autoloader.php`.

## ADDED Requirements
### Requirement: Resiliência Máxima de Autoloader
O Autoloader DEVE encontrar o arquivo PHP independentemente de como o cliente de FTP do usuário modificou as letras maiúsculas/minúsculas das pastas `Controllers`, `Models`, `Views`, etc.

#### Scenario: Success case
- **WHEN** o Router pede `App\Controllers\Superadmin\TenantController`
- **THEN** o Autoloader testa o caminho original, o caminho minúsculo e encontra o arquivo, retornando a classe e instanciando com sucesso.