# Fix Views Case Sensitivity on cPanel Spec

## Why
O sistema superou o roteador e o autoloader com sucesso e tentou renderizar a tela inicial. O erro `View /home2/coninfom/public_html/patrimonio/app/Views/home/index.php não encontrada.` indica que o mesmo problema de *Case-Sensitivity* (letras maiúsculas vs minúsculas) causado pelo cliente de FTP também afetou o carregamento das *Views*. A pasta `Views` no servidor provavelmente está com "v" minúsculo (`views`), enquanto o código procura por `Views`.

## What Changes
- Melhorar o método `render` na classe base `Core/Controller.php` para que ele seja resiliente ao *case-sensitivity* das pastas. Ele deverá tentar carregar a View no caminho exato fornecido (`app/Views/...`) e, caso não encontre, fazer o *fallback* para o caminho com as pastas em letras minúsculas (`app/views/...`).

## Impact
- Affected specs: Renderização de Views.
- Affected code: `Core/Controller.php`.

## ADDED Requirements
### Requirement: Resiliência no carregamento de Views
O sistema DEVE conseguir localizar e carregar os arquivos de View mesmo que a pasta pai `Views` tenha sido enviada ao servidor como `views` (minúsculo).

#### Scenario: Success case
- **WHEN** um controller chama `$this->render('home/index')`
- **THEN** o método `render` verifica se `/app/Views/home/index.php` existe. Se não existir, ele verifica se `/app/views/home/index.php` existe e realiza o `require_once` com sucesso.
