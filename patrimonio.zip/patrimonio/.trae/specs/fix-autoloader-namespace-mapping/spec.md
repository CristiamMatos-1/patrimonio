# Fix Autoloader Namespace Mapping Spec

## Why
Se o autoloader ainda retorna "NÃO FOI ENCONTRADA", mesmo tentando 3 formatos diferentes de *case-sensitivity*, o problema NÃO é mais de letras maiúsculas ou minúsculas no FTP. O problema é que **o Autoloader não sabe como lidar com sub-namespaces**.
No `index.php`, nós definimos:
`$autoloader->addNamespace('App', BASE_PATH . '/app');`
Quando o PHP procura `App\Controllers\Superadmin\TenantController`, o autoloader pega o prefixo inteiro (`App\Controllers\Superadmin\`) ou não consegue "fatiar" corretamente o caminho relativo (`TenantController`) a partir do diretório base (`/app`). A lógica nativa do `loadClass` que construímos (inspirada em um autoloader simplificado) falha quando a classe está muito profunda na hierarquia de pastas.

## What Changes
- Substituir a lógica manual e customizada do `Core/Autoloader.php` por uma implementação idêntica à do **padrão oficial PSR-4** (baseada na implementação de referência do PHP-FIG).
- Essa implementação oficial é matematicamente comprovada para resolver qualquer nível de sub-namespace de forma dinâmica, removendo o prefixo exato e traduzindo o resto do caminho para diretórios.

## Impact
- Affected specs: Carregamento de Classes PSR-4.
- Affected code: `Core/Autoloader.php`.

## ADDED Requirements
### Requirement: Conformidade estrita com PSR-4
O Autoloader DEVE ser idêntico à especificação oficial PSR-4, garantindo que `App\NamespaceA\NamespaceB\Classe` se traduza de forma impecável para `app/NamespaceA/NamespaceB/Classe.php`.

#### Scenario: Success case
- **WHEN** o Router pede `App\Controllers\Superadmin\TenantController`
- **THEN** o Autoloader PSR-4 oficial divide a string, mapeia o prefixo `App\` para a pasta `app/`, e o restante para `Controllers/Superadmin/TenantController.php`, e finalmente aplica as regras de *fallback case-insensitive* caso o arquivo não seja encontrado na primeira tentativa.