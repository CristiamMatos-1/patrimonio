# Fix 404 Deep Debug Spec

## Why
O sistema continua retornando 404 para a rota `/superadmin/tenant/create`, mesmo com o autoloader suportando pastas em minúsculo e a rota base `/` funcionando. Como já esgotamos as causas comuns (case-sensitivity no Autoloader e no Controller, problemas de `REQUEST_URI`), o 404 só pode estar vindo de dois lugares específicos no `Core/Router.php`:
1. A regex da rota não está "casando" (match) com a URL processada.
2. A função `class_exists()` ou `method_exists()` está retornando falso silenciosamente, fazendo o loop terminar e cair no 404 genérico.

Precisamos descobrir exatamente *qual* parte do fluxo do Router está falhando.

## What Changes
- Inserir blocos de debug profundo dentro do laço `foreach` do `Core/Router.php`. Ele deverá imprimir na tela o motivo exato de rejeitar uma rota em potencial.

## Impact
- Affected specs: Roteamento de URLs.
- Affected code: `Core/Router.php`.

## ADDED Requirements
### Requirement: Diagnóstico Preciso de Rotas
O Roteador DEVE expor na tela por que ele não conseguiu despachar uma URL específica para a classe e o método correspondentes.

#### Scenario: Success case
- **WHEN** o roteador não encontra o match
- **THEN** ele imprime na tela se o problema foi a Regex, a classe não encontrada ou o método não encontrado.