# Superadmin Login Implementation Spec

## Why
O usuário executou a query para criar um Superadmin específico (`99999999999`) na tabela `super_admins` do banco master. No entanto, a rota `/superadmin/tenant/create` atualmente está aberta (sem proteção de login). Precisamos implementar o fluxo de autenticação para que apenas o usuário `99999999999` (ou outros superadmins) consiga acessar a tela de provisionamento de novos clientes.

## What Changes
- Criar a tela de login exclusiva para o Superadmin (`/superadmin/login`).
- Criar o Controller de Autenticação do Superadmin (`SuperadminAuthController`).
- Criar um Middleware de Autenticação para proteger a rota do Superadmin (`SuperadminMiddleware`).
- Modificar as rotas no `index.php` para incluir o login do superadmin e proteger a rota de criação de tenants com o middleware.

## Impact
- Affected specs: Segurança e Autenticação do Superadmin.
- Affected code: `index.php`, `Core/Router.php` (para suportar middlewares de rota ou implementar o middleware diretamente no controller), `app/Controllers/Superadmin/`, `app/Views/superadmin/`.

## ADDED Requirements
### Requirement: Proteção da Rota do Superadmin
A rota `/superadmin/tenant/create` e qualquer outra rota administrativa global DEVE exigir que o usuário esteja autenticado como um Superadmin no banco master.

#### Scenario: Success case
- **WHEN** o usuário acessa `/superadmin/tenant/create` sem estar logado
- **THEN** ele é redirecionado para `/superadmin/login`.
- **WHEN** ele faz login com `99999999999` e senha `99999999999`
- **THEN** o sistema valida no banco master e redireciona para a tela de criação de tenants.