# Tasks
- [ ] Task 1: Criar o `SuperadminMiddleware` em `Core/Middleware/SuperadminMiddleware.php` para verificar a sessão `superadmin_logged_in`.
- [ ] Task 2: Atualizar o `TenantController` (`app/Controllers/Superadmin/TenantController.php`) para incluir a chamada ao `SuperadminMiddleware` no construtor.
- [ ] Task 3: Criar o `SuperadminAuthController` (`app/Controllers/Superadmin/AuthController.php`) com os métodos `loginForm`, `authenticate` e `logout`.
- [ ] Task 4: Criar a view de login (`app/Views/superadmin/login.php`).
- [ ] Task 5: Registrar as novas rotas no `index.php`.