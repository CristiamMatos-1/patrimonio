# Fix File Path Resolution Spec

## Why
Se o arquivo existe fisicamente no cPanel (com o nome exato `TenantController.php`), mas a função `file_exists()` do PHP está retornando falso para todas as 3 tentativas, o problema está na forma como o PHP está resolvendo o caminho base (o prefixo do diretório).
O código atual usa `$baseDir = dirname(__DIR__) . '/app/Controllers/';`. Dependendo de como o cPanel ou o servidor LiteSpeed/FPM resolve symlinks ou o diretório de execução, `dirname(__DIR__)` dentro de `Core/Router.php` pode não estar retornando o caminho absoluto esperado (ex: `/home2/coninfom/public_html/patrimonio`). Se o caminho inicial estiver quebrado, o `file_exists` nunca encontrará o arquivo.

## What Changes
- Vamos expor exatamente quais são as 3 strings de caminho físico que o PHP está tentando buscar no disco.
- Adicionaremos essas strings ao `debugLog`. Assim, o usuário verá exatamente onde o PHP acha que a pasta `app` está.
- Vamos usar a constante `BASE_PATH` (que foi definida no `index.php` usando `__DIR__`) em vez de calcular `dirname(__DIR__)` dentro do Roteador, pois o `BASE_PATH` é absoluto e confiável a partir da raiz da requisição.

## Impact
- Affected specs: Resolução de caminho físico no Router.
- Affected code: `Core/Router.php`.

## ADDED Requirements
### Requirement: Resolução Confiável de Diretório e Transparência
O Roteador DEVE usar a constante `BASE_PATH` para construir caminhos físicos absolutos de forma segura e DEVE imprimir esses caminhos no log se a tentativa falhar.

#### Scenario: Success case
- **WHEN** o Router tenta fazer o require direto
- **THEN** ele usa `BASE_PATH . '/app/Controllers/...` e se falhar, imprime o caminho exato testado na tela.