# Fix Autoloader Namespace Case Resolution Spec

## Why
O log continua exatamente o mesmo: `ERRO: Classe App\Controllers\Superadmin\TenantController NÃO FOI ENCONTRADA pelo Autoloader`.
Se o autoloader é a versão oficial PSR-4 e o fallback de minúsculas/maiúsculas está ativo, só existe um último motivo lógico e absoluto para a função `requireFile` falhar em todos os testes no Linux: **o case (letras maiúsculas/minúsculas) da própria palavra `App` ou a declaração `namespace` dentro do arquivo PHP não está batendo**.
Lembre-se: O index define `$autoloader->addNamespace('App', BASE_PATH . '/app');`.
No PHP, nomes de classes e namespaces não são case-sensitive *em memória*, mas o Autoloader *é* case-sensitive ao mapear o array `$this->prefixes`. Além disso, se o nome da pasta local é `app` (minúsculo) e a namespace no arquivo for `App` (maiúsculo), ou se o autoloader estiver comparando com a barra invertida e caindo em um false negativo, ele não tenta ler o disco.
Vamos forçar o Autoloader a realizar um "Deep Scan" final. Se ele falhar pelo PSR-4, ele vai construir o caminho absoluto usando `BASE_PATH` na força bruta, cortando a palavra "App", e testar se o arquivo físico `app/Controllers/Superadmin/TenantController.php` (e suas variações minúsculas) existe.

## What Changes
- Inserir um método de "força bruta" no `loadClass` do Autoloader. Se a busca elegante do PSR-4 falhar (por não encontrar a chave no array de prefixos devido a conflitos de Case/Namespace), ele vai remover a palavra `App\` do nome da classe, colocar a pasta `app/` no lugar e testar as 3 variações físicas no disco (`app/Controllers...`, `app/controllers...`, etc).

## Impact
- Affected specs: Carregamento de Classes PSR-4.
- Affected code: `Core/Autoloader.php`.

## ADDED Requirements
### Requirement: Fallback Físico de Força Bruta
O Autoloader DEVE ter um último recurso que ignora o mapeamento de prefixos lógicos se estes falharem e constrói o caminho físico diretamente baseando-se na palavra `App`.

#### Scenario: Success case
- **WHEN** o Router pede `App\Controllers\Superadmin\TenantController` e o mapeamento PSR-4 falha por qualquer motivo
- **THEN** o Autoloader tenta `BASE_PATH . '/app/Controllers/Superadmin/TenantController.php'`, e depois `BASE_PATH . '/app/controllers/superadmin/TenantController.php'`, instanciando a classe.