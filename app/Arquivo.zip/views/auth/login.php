<?php declare(strict_types=1); ?>

<?php use App\Lib\Http; ?>

<div class="row justify-content-center">
    <div class="col-12 col-md-6 col-lg-4">
        <h1 class="h4 mb-3">Entrar</h1>
        <form method="post" action="<?= htmlspecialchars(Http::path('/login')) ?>" class="vstack gap-3">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
            <div>
                <label for="email" class="form-label">E-mail</label>
                <input type="email" class="form-control" id="email" name="email" required autocomplete="username">
            </div>
            <div>
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="senha" name="senha" required autocomplete="current-password">
            </div>
            <button class="btn btn-primary" type="submit">Entrar</button>
        </form>
    </div>
</div>
