<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Lib\Auth;
use App\Lib\Csrf;
use App\Lib\Flash;
use App\Lib\Http;
use App\Lib\View;
use App\Models\User;

final class AuthController extends BaseController
{
    public function loginForm(): void
    {
        if (Auth::check()) {
            Http::redirect('/');
        }
        View::render($this->config, 'auth/login', [
            'title' => 'Login',
        ]);
    }

    public function login(): void
    {
        Csrf::verify($_POST['csrf_token'] ?? null);

        $email = trim((string) ($_POST['email'] ?? ''));
        $senha = (string) ($_POST['senha'] ?? '');

        if ($email === '' || $senha === '') {
            Flash::add('danger', 'Informe e-mail e senha.');
            Http::redirect('/login');
        }

        $user = User::findByEmail($this->pdo, $email);
        if ($user === null || (int) $user['ativo'] !== 1 || !password_verify($senha, (string) $user['senha_hash'])) {
            Flash::add('danger', 'Credenciais inválidas.');
            Http::redirect('/login');
        }

        Auth::login($user);
        Flash::add('success', 'Bem-vindo, ' . $user['nome'] . '.');
        Http::redirect('/');
    }

    public function logout(): void
    {
        Csrf::verify($_POST['csrf_token'] ?? null);
        Auth::logout();
        Flash::add('success', 'Sessão encerrada.');
        Http::redirect('/login');
    }
}

